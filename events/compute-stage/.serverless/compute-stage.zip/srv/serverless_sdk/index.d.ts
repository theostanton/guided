declare const _exports: any;
export = _exports;
//# sourceMappingURL=index.d.ts.map