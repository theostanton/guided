"use strict";
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
    orgId: 'theostanton',
    applicationName: 'guided',
    appUid: '0RVNdcBVW71b2KfJPk',
    orgUid: '8PH7JG2qyPDSQhCltX',
    deploymentUid: 'f2d78d3f-597e-4276-9e24-860b60a61d79',
    serviceName: 'compute-stage',
    stageName: 'staging',
    pluginVersion: '3.3.0'
});
const handlerWrapperArgs = { functionName: 'compute-stage-staging-compute', timeout: 6 };
try {
    const userHandler = require('./srv/lambda.js');
    module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
}
catch (error) {
    module.exports.handler = serverlessSDK.handler(() => { throw error; }, handlerWrapperArgs);
}
//# sourceMappingURL=s_compute.js.map