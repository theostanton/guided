export var handler: any;
//# sourceMappingURL=s_compute.d.ts.map