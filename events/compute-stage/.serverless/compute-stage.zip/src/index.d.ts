export declare type ComputeRideMessageBody = {
    someField: string;
};
//# sourceMappingURL=index.d.ts.map