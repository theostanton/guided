import { ComputeRideMessageBody } from "./index";
export default function (body: ComputeRideMessageBody): Promise<void>;
//# sourceMappingURL=action.d.ts.map