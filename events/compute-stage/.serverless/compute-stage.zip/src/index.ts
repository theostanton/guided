

export type ComputeRideMessageBody = {
  someField: string
}
