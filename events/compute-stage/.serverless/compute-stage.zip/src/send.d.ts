import { ComputeRideMessageBody } from "./index";
export default function send(body: ComputeRideMessageBody): Promise<void>;
//# sourceMappingURL=send.d.ts.map