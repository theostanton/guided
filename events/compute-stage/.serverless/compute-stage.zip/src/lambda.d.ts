export declare function handler(event: any, context: any): Promise<any>;
//# sourceMappingURL=lambda.d.ts.map