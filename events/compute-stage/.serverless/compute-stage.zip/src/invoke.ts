import send from "./send"

async function execute() {
  console.log("execute")
  await send({
    someField: "Some value!!",
  })
}

execute()