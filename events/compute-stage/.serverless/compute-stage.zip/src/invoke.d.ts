export {};
//# sourceMappingURL=invoke.d.ts.map