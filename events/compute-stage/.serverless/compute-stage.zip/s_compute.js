var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'theostanton',
applicationName: 'guided',
appUid: '0RVNdcBVW71b2KfJPk',
orgUid: '8PH7JG2qyPDSQhCltX',
deploymentUid: '29bb6b56-db21-40c3-98af-62899cf5a834',
serviceName: 'compute-stage',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'compute-stage-dev-compute', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.index, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
